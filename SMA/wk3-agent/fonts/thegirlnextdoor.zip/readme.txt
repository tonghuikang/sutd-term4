This font was created by Kimberly Geswein.
It is for personal use only.  If you wish to use it commercially I ask for 
a one-time US $5 paypal payment to Kimberly at gesweinfamily@gmail.com

Paying the commercial license fee gives you unlimited usage of this
font for your t-shirts, advertisements, websites, whatever you wish! 

For non-profit and/or non-commercial usage-- as long as your
stuff is not racist, hateful, or anti-Christian, you are free to use it as 
you wish!  

For all have sinned and come short of the glory of God.  Romans 3:23
For the wages of sin is death; but the free gift of God is eternal life in Christ Jesus our Lord.  Romans 6:23

